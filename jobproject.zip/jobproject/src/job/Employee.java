package job;

import java.util.Set;

public class Employee {

	private int emp_id;
	private String emp_name;
	private float emp_salary;
	private Set<Address> addresses;			//Set<Jobs> jobs;
	
	
	public Set<Address> getAddresses() {   //ServiceProvider   Set<Jobs>getJobs
		return addresses;
	}
	public void setAddresses(Set<Address> addresses) {
		this.addresses = addresses;
	}
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public float getEmp_salary() {
		return emp_salary;
	}
	public void setEmp_salary(float emp_salary) {
		this.emp_salary = emp_salary;
	}
	
	
}
