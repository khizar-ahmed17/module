package job;

public class Applied 
{
	private int id;
	private int applied;
	private String jobname;
	private String requestername;
	private String cname;
	private ServiceProvider appobj;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getApplied() {
		return applied;
	}
	public void setApplied(int applied) {
		this.applied = applied;
	}
	public ServiceProvider getAppobj() {
		return appobj;
	}
	public void setAppobj(ServiceProvider appobj) {
		this.appobj = appobj;
	}
	public String getJobname() {
		return jobname;
	}
	public void setJobname(String jobname) {
		this.jobname = jobname;
	}
	public String getRequestername() {
		return requestername;
	}
	public void setRequestername(String requestername) {
		this.requestername = requestername;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	
	
}
