package job;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;

public class Demo 
{
public static void main(String[] args) 
{
	

/*
	
	
	ServiceProvider service=new ServiceProvider();
	service.setSp_name("company");
	service.setSp_username("company");
	service.setSp_password("root");
	service.setSp_email("company@gamil.com");
	service.setSp_website("company.com");
	service.setSp_status(0);
	service.setSp_address("1st Street");
	service.setApply_request(0);
	
	
	
	Applied i=new Applied();
	i.setApplied(0);
	i.setAppobj(service);


	Jobs j=new Jobs();
	j.setJob_id(1);
	j.setJob_name("java developer");
	j.setJob_amount(5000);
	j.setJob_experience("2 Years");
	j.setJob_specialization("python");
	j.setSpobj(service);
	


	
	
	ServiceRequester service1=new ServiceRequester();
	service1.setRq_id(1);
	service1.setRq_name("name");
	service1.setRq_username("job");
	service1.setRq_password("job");
	service1.setRq_email("job@gmail.com");
	service1.setRq_address("new street");
	service1.setRq_contact(2);
	service1.setRq_status(0);
	
	RequestJobs jb=new RequestJobs();
	jb.setJob_id(1);
	jb.setJob_experience("1 Year");
	jb.setJob_name("Developer");
	jb.setJob_specialization("Java");
	jb.setJob_amount(20000);
	jb.setRqobj(service1);
	
	// e n d
	

	*/
	
	//
	
	


	
	ServiceProvider service1=new ServiceProvider();
	service1.setSp_name("onecompany");
	service1.setSp_username("onecompany");
	service1.setSp_password("root");
	service1.setSp_email("onecompany@gamil.com");
	service1.setSp_website("onecompany.com");
	service1.setSp_status(0);
	service1.setSp_address("First Street");
	service1.setApply_request(0);
	
//	Applied i=new Applied();
//	i.setApplied(0);
//	i.setAppobj(service1);
	
	
	
	Jobs j1=new Jobs();
	j1.setJob_name("dot net developer");
	j1.setJob_amount(1000);
	j1.setJob_experience("1 Years");
	j1.setJob_specialization("dot net");
	j1.setSpobj(service1);
	
	

	
	ServiceRequester service2=new ServiceRequester();
	service2.setRq_name("Ramu");
	service2.setRq_username("ramu");
	service2.setRq_password("root");
	service2.setRq_email("ramu@gmail.com");
	service2.setRq_address("rajiv nagar street");
	service2.setRq_contact(895461238);
	service2.setRq_status(0);
	
	RequestJobs jb1=new RequestJobs();
	jb1.setJob_experience("2 Year");
	jb1.setJob_name("Supporter");
	jb1.setJob_specialization("Java");
	jb1.setJob_amount(15000);
	jb1.setRqobj(service2);
	
	


	
	Set<Jobs> set=new HashSet<Jobs>();
	
	
	Set<Applied> app=new HashSet<Applied>();
	
	set.add(j1);
	service1.setJobs(set);
	//set.add(j);
	//service.setJobs(set);
	
	
	//if you dont save the applied to set, then the provider_id will be assigned as null
//	app.add(i);
	
	
	//service.setApplied(app);

	
	Set<RequestJobs> set1=new HashSet<RequestJobs>();
	
	set1.add(jb1);
	service2.setJobs(set1);
	//set1.add(jb);
	//service1.setJobs(set1);
	
	
	Session session=(Session) SessionUtility.GetSessionConnection();
	//session.save(service);
	//session.save(j);
	
//	session.save(i);
	
	session.save(service1);
	session.save(j1);
	
	
	//session.save(service1);
	//session.save(jb);
	session.save(service2);
	session.save(jb1);
	
	
	
	SessionUtility.closeSession(null);									
	
	
	
	
	

	/*
	
//	Condition to get the name of the requester who is specialized in a particular job
	Session session1=(Session)SessionUtility.GetSessionConnection();
	
	Criteria cr=session1.createCriteria(ServiceRequester.class,"ser");
	cr.createAlias("ser.jobs", "ad");
	cr.add(Restrictions.eq("ad.job_specialization","Java"));	
	List<ServiceRequester> ad=cr.list();
	Iterator it=ad.iterator();
	System.out.println(ad);
	if(it.hasNext())
	{
		System.out.println("in loop");
		ServiceRequester s=(ServiceRequester) it.next();
		System.out.println(s.getRq_name());
	}
	System.out.println("what am i"+ad.get(0).getRq_username());
	
	
	*/
	
	
	
	/*
	
	//Condition to get the available jobs from the company
	
	Session session2=(Session)SessionUtility.GetSessionConnection();
	Query q=session2.createQuery("From job.ServiceProvider");
	
	List<ServiceProvider> results = q.list();
	
	Iterator<ServiceProvider> itr=results.iterator();
	
	Set<Jobs> se=itr.next().getJobs();
	
	Iterator<Jobs> ads=se.iterator();
	
	while (ads.hasNext()) {
		Jobs a=ads.next();
		
		System.out.println(a.getJob_name());
			
	}
									
	
	*/
	
	/*
	
	//To get A particular column - For Displaying Specialization from Request Jobs
	Session session1=(Session)SessionUtility.GetSessionConnection();
	Criteria cr = session1.createCriteria(RequestJobs.class)
		    .setProjection(Projections.projectionList()
		      .add(Projections.property("job_specialization"), "job_specialization"))
		    .setResultTransformer(Transformers.aliasToBean(RequestJobs.class));

		  List<RequestJobs> list = cr.list();
		  Iterator<RequestJobs> iter=list.iterator();
		  while(iter.hasNext())
		  {
			  System.out.println(iter.next().getJob_specialization());
		  }
		  
		  
		  
		  */
	
	
	/*
	
	//When SercviceRequester logins
	
	//To get A particular column - For Displaying Specialization from Jobs
		Session session1=(Session)SessionUtility.GetSessionConnection();
		Criteria cr = session1.createCriteria(Jobs.class)
			    .setProjection(Projections.projectionList()
			      .add(Projections.property("job_name"), "job_name"))
			    .setResultTransformer(Transformers.aliasToBean(Jobs.class));

			  List<Jobs> list = cr.list();
			  Iterator<Jobs> iter=list.iterator();
			  while(iter.hasNext())
			  {
				  System.out.println(iter.next().getJob_name());
			  }
	
	
	
	*/
	
	
	/*
//	Condition to get the name of the Company who has posted a particular job
	Session session1=(Session)SessionUtility.GetSessionConnection();
	
	Criteria cr=session1.createCriteria(ServiceProvider.class,"ser");
	cr.createAlias("ser.jobs", "ad");
	cr.add(Restrictions.eq("ad.job_name","java developer"));	
	List<ServiceProvider> ad=cr.list();
	Iterator<ServiceProvider> it=ad.iterator();
	System.out.println(ad);
	while(it.hasNext())
	{
		System.out.println("in loop");
		System.out.println(it.next().getSp_username());
		
	}
	//System.out.println("what am i"+ad.get(0).getRq_username());
	
	
	*/
	
	
	/*
		  
	//updating the value of field in a sql
	
	Session session=(Session)SessionUtility.GetSessionConnection();
	String hql = "FROM job.ServiceProvider";
	Query query = session.createQuery(hql);
	List<ServiceProvider> results = query.list();
	Iterator<ServiceProvider> it=results.iterator();
	it.next().setApply_request(0);
	
	SessionUtility.closeSession(null);
	
	*/
	
	
	
	//inorder to know the reqid
	
	
	/*
	
	
	
	Session session=(Session)SessionUtility.GetSessionConnection();
	
	// int employeeId = 1;
	String username="ramu";
	
	   Criteria criteria = session.createCriteria(ServiceRequester.class);
	   
	               criteria.add(Restrictions.eq("rq_username",username));
	               
	   
	                
	   
	              ServiceRequester requester = (ServiceRequester) criteria.uniqueResult();
	   
	                
	   
	               if (requester!=null) {
	   
	                   System.out.println("Employee found:");
	   
	                   System.out.println(requester.getRq_id() + " - " + requester.getRq_name());
	   
	               }

	
	
	*/
	
//	
//	Session session2=(Session)SessionUtility.GetSessionConnection();
//	Query q=session2.createQuery("From job.ServiceRequester");
//	
//	List<ServiceRequester> results = q.list();
//	
//	Iterator<ServiceRequester> itr=results.iterator();


//	if(itr.next().getRq_id()==1)
//	{
//		System.out.println(itr.next().getRq_username());
//		
//	}
	
//	while(itr.hasNext())
//	{
//		if(itr.next().getRq_username().equals("job"))
//		{
//			System.out.println("g");
//			System.out.println(itr.next().getRq_id());
//		}
//		
//	}
//	
	
//	while(itr.hasNext())
//	{
//		while(itr.next().getRq_id()==2)
//		{
//		
//		System.out.println(itr.next().getRq_username());
//		}
//	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	
	
	//When candidates applies for a post,it has to be updated in Providers db
	//Note:we Know requesters id
	//Working fine
	
	int req1d=1;
	int getspid = 0;
	
	Session session1=(Session)SessionUtility.GetSessionConnection();
	String hql = "FROM job.Jobs where job_name = :jobname";
	
	Query query = session1.createQuery(hql);
	query.setString("jobname","dot net developer");
	
	

	
	
	@SuppressWarnings("unchecked")
	List<Jobs> results = query.list();
	System.out.println(results);
	Iterator<Jobs> it=results.iterator();
	
	if (it.hasNext())
	{
		getspid=it.next().getSpobj().getSp_id();
		System.out.println(getspid);
		
		//updating the applyrequest to reqid value
	}
	
		String hql1 = "FROM job.ServiceProvider where sp_id = :spid";
		Query query1 = session1.createQuery(hql1);
		query1.setInteger("spid", getspid);
		@SuppressWarnings("unchecked")
		List<ServiceProvider> results1 = query1.list();
		System.out.println(results1);
		Iterator<ServiceProvider> iter=results1.iterator();
		if(iter.hasNext())
		{
			
			iter.next().setApply_request(req1d);
			//session1.save(hql);
			//SessionUtility.closeSession(null);
		}
		
		
		
	
	SessionUtility.closeSession(null);
	
	
			  
	
	*/
	
	
	

	
	/*
	 * 
	 * Updating the value of apply request
	 * 
	int reqid=1;
	int getspid=1;
	 
	Session session1=(Session)SessionUtility.GetSessionConnection();
	String hql = "FROM job.ServiceProvider where sp_id = :spid";
	
	
//	Session session1=(Session)SessionUtility.GetSessionConnection();
//	String hql = "FROM job.Jobs where job_name = :jobname";
	
	Query query = session1.createQuery(hql);
	query.setInteger("spid", getspid);
	
	

	
	
	@SuppressWarnings("unchecked")
	List<ServiceProvider> results = query.list();
	System.out.println(results);
	Iterator<ServiceProvider> it=results.iterator();
	if(it.hasNext())
	{
		
		it.next().setApply_request(1);
		//session1.save(hql);
		SessionUtility.closeSession(null);
	}
	

}	
	

	*/
	
	
	}

}